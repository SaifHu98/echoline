</main>

<?php if (Auth::check()): ?>
<script src="assets/admin.js"></script>
<?php endif; ?>
</body>
</html>