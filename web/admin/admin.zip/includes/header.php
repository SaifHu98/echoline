<?php
/**
 * Header layout — used by all admin pages
 */
if (!defined('ADMIN_INCLUDED')) define('ADMIN_INCLUDED', 1);

require_once __DIR__ . '/../config.php';
Security::startSession();

$pageTitle = $pageTitle ?? I18n::t('dashboard.welcome');
$currentSection = $currentSection ?? 'dashboard';
$csrfToken = Security::csrfToken();
?>
<!DOCTYPE html>
<html lang="<?= I18n::locale() ?>" dir="<?= I18n::direction() ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= Security::escape($pageTitle) ?> — <?= APP_NAME ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&family=Outfit:wght@400;600;700;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/admin.css">
  <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cpath fill='%2300E5FF' d='M32 2 L60 32 L32 62 L4 32 Z'/%3E%3Cpath fill='%23D4AF37' d='M32 14 L48 32 L32 50 L16 32 Z'/%3E%3C/svg%3E">
</head>
<body>
  <input type="hidden" id="csrf-token" value="<?= $csrfToken ?>">

  <?php if (Auth::check()): ?>
  <aside class="sidebar">
    <div class="brand">
      <div class="brand-logo"></div>
      <div class="brand-info">
        <div class="brand-title"><?= APP_NAME ?></div>
        <div class="brand-sub">Admin Panel</div>
      </div>
    </div>

    <nav class="nav">
      <a href="dashboard.php" class="nav-item <?= $currentSection === 'dashboard' ? 'active' : '' ?>">
        <span class="ic">📊</span><span><?= I18n::t('menu.dashboard') ?></span>
      </a>
      <a href="events.php" class="nav-item <?= $currentSection === 'events' ? 'active' : '' ?>">
        <span class="ic">🎯</span><span><?= I18n::t('menu.events') ?></span>
      </a>
      <a href="quests.php" class="nav-item <?= $currentSection === 'quests' ? 'active' : '' ?>">
        <span class="ic">⚔️</span><span><?= I18n::t('menu.quests') ?></span>
      </a>
      <a href="shop.php" class="nav-item <?= $currentSection === 'shop' ? 'active' : '' ?>">
        <span class="ic">💎</span><span><?= I18n::t('menu.shop') ?></span>
      </a>
      <a href="scenarios.php" class="nav-item <?= $currentSection === 'scenarios' ? 'active' : '' ?>">
        <span class="ic">🗺️</span><span><?= I18n::t('menu.scenarios') ?></span>
      </a>
      <a href="echo_system.php" class="nav-item <?= $currentSection === 'echo' ? 'active' : '' ?>">
        <span class="ic">🌀</span><span><?= I18n::t('menu.echo') ?></span>
      </a>
      <a href="players.php" class="nav-item <?= $currentSection === 'players' ? 'active' : '' ?>">
        <span class="ic">👥</span><span><?= I18n::t('menu.players') ?></span>
      </a>
      <a href="reports.php" class="nav-item <?= $currentSection === 'reports' ? 'active' : '' ?>">
        <span class="ic">🛡️</span><span><?= I18n::t('menu.reports') ?></span>
      </a>
      <a href="receipts.php" class="nav-item <?= $currentSection === 'receipts' ? 'active' : '' ?>">
        <span class="ic">🧾</span><span><?= I18n::t('menu.receipts') ?></span>
      </a>
      <a href="remote_config.php" class="nav-item <?= $currentSection === 'config' ? 'active' : '' ?>">
        <span class="ic">⚙️</span><span><?= I18n::t('menu.config') ?></span>
      </a>
      <a href="announcements.php" class="nav-item <?= $currentSection === 'announcements' ? 'active' : '' ?>">
        <span class="ic">📢</span><span><?= I18n::t('menu.announcements') ?></span>
      </a>
      <a href="localization.php" class="nav-item <?= $currentSection === 'localization' ? 'active' : '' ?>">
        <span class="ic">🌍</span><span><?= I18n::t('menu.localization') ?></span>
      </a>
      <a href="analytics.php" class="nav-item <?= $currentSection === 'analytics' ? 'active' : '' ?>">
        <span class="ic">📈</span><span><?= I18n::t('menu.analytics') ?></span>
      </a>
      <a href="audit.php" class="nav-item <?= $currentSection === 'audit' ? 'active' : '' ?>">
        <span class="ic">📜</span><span><?= I18n::t('menu.audit') ?></span>
      </a>
      <?php if (in_array(Auth::role(), ['superadmin'], true)): ?>
      <a href="admins.php" class="nav-item <?= $currentSection === 'admins' ? 'active' : '' ?>">
        <span class="ic">🔐</span><span><?= I18n::t('menu.admins') ?></span>
      </a>
      <?php endif; ?>
    </nav>

    <div class="sidebar-foot">
      <div class="user-card">
        <div class="user-avatar"><?= mb_strtoupper(mb_substr(Auth::user()['username'] ?? '?', 0, 1)) ?></div>
        <div class="user-info">
          <div class="user-name"><?= Security::escape(Auth::user()['username'] ?? '') ?></div>
          <div class="user-role"><?= Security::escape(Auth::role() ?? '') ?></div>
        </div>
      </div>
      <a href="logout.php" class="btn ghost block"><?= I18n::t('common.logout') ?></a>
    </div>
  </aside>
  <?php endif; ?>

  <main class="main">
    <?php if (!empty($flashMessage)): ?>
      <div class="flash flash-<?= Security::escape($flashType ?? 'info') ?>">
        <?= Security::escape($flashMessage) ?>
      </div>
    <?php endif; ?>