<?php
require_once __DIR__ . '/config.php';
Security::startSession();

if (Auth::check()) {
    Response::redirect('dashboard.php');
}

$error = null;
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $token = $_POST[CSRF_TOKEN_NAME] ?? '';

    if (!Security::verifyCsrf($token)) {
        $error = I18n::t('error.csrf');
    } else {
        try {
            Auth::login($username, $password);
            Response::redirect('dashboard.php');
        } catch (\Throwable $e) {
            $error = $e->getMessage();
        }
    }
}

$csrfToken = Security::csrfToken();
?>
<!DOCTYPE html>
<html lang="<?= I18n::locale() ?>" dir="<?= I18n::direction() ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= I18n::t('login.title') ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&family=Outfit:wght@400;600;700;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/admin.css">
</head>
<body class="login-page">
  <div class="login-card">
    <div class="login-brand">
      <div class="brand-logo"></div>
      <h1><?= APP_NAME ?></h1>
      <p class="text-muted"><?= I18n::t('login.title') ?></p>
    </div>

    <?php if ($error): ?>
      <div class="alert alert-error"><?= Security::escape($error) ?></div>
    <?php endif; ?>

    <form method="POST" autocomplete="on">
      <input type="hidden" name="<?= CSRF_TOKEN_NAME ?>" value="<?= $csrfToken ?>">
      <div class="form-group">
        <label><?= I18n::t('login.username') ?></label>
        <input type="text" name="username" required autofocus value="<?= Security::escape($username) ?>" autocomplete="username">
      </div>
      <div class="form-group">
        <label><?= I18n::t('login.password') ?></label>
        <input type="password" name="password" required autocomplete="current-password">
      </div>
      <button type="submit" class="btn primary block large"><?= I18n::t('login.submit') ?></button>
    </form>

    <div class="login-hint">
      <small>الافتراضي: admin / admin123 (غيّرها فوراً بعد الدخول الأول)</small>
    </div>
  </div>
</body>
</html>