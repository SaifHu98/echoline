<?php
require_once __DIR__ . '/config.php';
Auth::require();

$pageTitle = I18n::t('menu.analytics');
$currentSection = 'analytics';

// Analytics queries
$daily = Database::fetchAll(
    "SELECT DATE(created_at) AS day, COUNT(*) AS matches
     FROM analytics_events
     WHERE event_name = 'match_completed' AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
     GROUP BY DATE(created_at) ORDER BY day"
);

$byOutcome = Database::fetchAll(
    "SELECT JSON_UNQUOTE(JSON_EXTRACT(event_data, '$.outcome')) AS outcome, COUNT(*) AS c
     FROM analytics_events
     WHERE event_name = 'match_completed' AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
     GROUP BY outcome"
);

$byScenario = Database::fetchAll(
    "SELECT JSON_UNQUOTE(JSON_EXTRACT(event_data, '$.scenario')) AS scenario, COUNT(*) AS c
     FROM analytics_events
     WHERE event_name = 'match_completed' AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
     GROUP BY scenario ORDER BY c DESC LIMIT 10"
);

$byTimeline = Database::fetchAll(
    "SELECT JSON_UNQUOTE(JSON_EXTRACT(event_data, '$.timeline')) AS tl, COUNT(*) AS c
     FROM analytics_events
     WHERE event_name = 'play_timeline' AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
     GROUP BY tl"
);

$topCountries = Database::fetchAll(
    "SELECT country_code, COUNT(DISTINCT player_uid) AS c
     FROM analytics_events
     WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) AND country_code IS NOT NULL
     GROUP BY country_code ORDER BY c DESC LIMIT 10"
);

include __DIR__ . '/includes/header.php';
?>

<div class="page-header">
  <h1>تحليلات اللعبة (آخر 30 يوم)</h1>
</div>

<div class="grid-2col">
  <div class="panel">
    <h3>المباريات اليومية</h3>
    <canvas id="dailyChart" style="width:100%;height:240px;"></canvas>
  </div>

  <div class="panel">
    <h3>توزيع النتائج</h3>
    <canvas id="outcomeChart" style="width:100%;height:240px;"></canvas>
  </div>

  <div class="panel">
    <h3>أكثر السيناريوهات لعباً</h3>
    <canvas id="scenarioChart" style="width:100%;height:240px;"></canvas>
  </div>

  <div class="panel">
    <h3>توزيع الخطوط الزمنية</h3>
    <canvas id="timelineChart" style="width:100%;height:240px;"></canvas>
  </div>
</div>

<div class="panel">
  <h3>أعلى الدول</h3>
  <table class="data-table">
    <thead><tr><th>الدولة</th><th>اللاعبون</th></tr></thead>
    <tbody>
      <?php foreach ($topCountries as $c): ?>
        <tr><td><code><?= Security::escape($c['country_code']) ?></code></td><td><?= number_format($c['c']) ?></td></tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
const COLORS = {
  cyan: '#00E5FF', amber: '#D4AF37', green: '#00E676', violet: '#9013FE',
  red: '#FF5252', copper: '#B87333', pink: '#FF80AB'
};

new Chart(document.getElementById('dailyChart'), {
  type: 'bar',
  data: {
    labels: <?= json_encode(array_column($daily, 'day')) ?>,
    datasets: [{ label: 'Matches', data: <?= json_encode(array_column($daily, 'matches')) ?>, backgroundColor: COLORS.cyan }]
  },
  options: chartOpts()
});

new Chart(document.getElementById('outcomeChart'), {
  type: 'doughnut',
  data: {
    labels: <?= json_encode(array_column($byOutcome, 'outcome')) ?>,
    datasets: [{
      data: <?= json_encode(array_column($byOutcome, 'c')) ?>,
      backgroundColor: [COLORS.green, COLORS.amber, COLORS.copper, COLORS.red, COLORS.violet]
    }]
  },
  options: { ...chartOpts(), plugins: { legend: { labels: { color: '#fff' }, position: 'right' } } }
});

new Chart(document.getElementById('scenarioChart'), {
  type: 'bar',
  data: {
    labels: <?= json_encode(array_column($byScenario, 'scenario')) ?>,
    datasets: [{ label: 'Matches', data: <?= json_encode(array_column($byScenario, 'c')) ?>, backgroundColor: COLORS.amber }]
  },
  options: { ...chartOpts(), indexAxis: 'y' }
});

new Chart(document.getElementById('timelineChart'), {
  type: 'pie',
  data: {
    labels: <?= json_encode(array_column($byTimeline, 'tl')) ?>,
    datasets: [{
      data: <?= json_encode(array_column($byTimeline, 'c')) ?>,
      backgroundColor: [COLORS.amber, COLORS.cyan, COLORS.violet]
    }]
  },
  options: { ...chartOpts(), plugins: { legend: { labels: { color: '#fff' }, position: 'right' } } }
});

function chartOpts() {
  return {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { labels: { color: '#fff' } } },
    scales: {
      x: { ticks: { color: '#8E9BAE' }, grid: { color: 'rgba(255,255,255,0.05)' } },
      y: { ticks: { color: '#8E9BAE' }, grid: { color: 'rgba(255,255,255,0.05)' } }
    }
  };
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>