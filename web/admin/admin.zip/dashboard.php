<?php
require_once __DIR__ . '/config.php';
Auth::require();

$pageTitle = I18n::t('dashboard.welcome');
$currentSection = 'dashboard';

// Fetch key metrics
$stats = [];

// Active events
$stats['active_events'] = (int) Database::fetch(
    'SELECT COUNT(*) AS c FROM events WHERE is_active = 1 AND NOW() BETWEEN start_at AND end_at'
)['c'];

// Matches today
$stats['matches_today'] = (int) Database::fetch(
    "SELECT COUNT(*) AS c FROM analytics_events WHERE event_name = 'match_completed' AND DATE(created_at) = CURDATE()"
)['c'];

// Revenue today
$stats['revenue_today'] = (float) Database::fetch(
    "SELECT COALESCE(SUM(amount_usd), 0) AS s FROM sales_log WHERE status = 'verified' AND DATE(created_at) = CURDATE()"
)['s'];

$stats['revenue_month'] = (float) Database::fetch(
    "SELECT COALESCE(SUM(amount_usd), 0) AS s FROM sales_log WHERE status = 'verified' AND YEAR(created_at) = YEAR(NOW()) AND MONTH(created_at) = MONTH(NOW())"
)['s'];

// Total players
$stats['total_players'] = (int) Database::fetch('SELECT COUNT(*) AS c FROM players')['c'];

// Online players (last 5 minutes)
$stats['players_online'] = (int) Database::fetch(
    "SELECT COUNT(*) AS c FROM players WHERE last_login_at >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)"
)['c'];

// 7-day retention (players who logged in today AND 7 days ago)
$stats['retention_7d'] = 0;
$totalOld = (int) Database::fetch(
    "SELECT COUNT(*) AS c FROM players WHERE last_login_at >= DATE_SUB(NOW(), INTERVAL 8 DAY) AND last_login_at <= DATE_SUB(NOW(), INTERVAL 7 DAY)"
)['c'];
$returned = (int) Database::fetch(
    "SELECT COUNT(*) AS c FROM players WHERE last_login_at >= DATE_SUB(NOW(), INTERVAL 8 DAY) AND last_login_at <= DATE_SUB(NOW(), INTERVAL 7 DAY) AND last_login_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)"
)['c'];
if ($totalOld > 0) {
    $stats['retention_7d'] = round(($returned / $totalOld) * 100, 1);
}

// Open reports
$stats['open_reports'] = (int) Database::fetch("SELECT COUNT(*) AS c FROM reports WHERE status = 'open'")['c'];

// Active scenarios (from files)
$scenarioFiles = glob(__DIR__ . '/data/scenarios/*.json');
$stats['total_scenarios'] = count($scenarioFiles);

// Recent sales
$recentSales = Database::fetchAll(
    'SELECT s.*, p.display_name FROM sales_log s
     LEFT JOIN players p ON p.player_uid = s.player_id
     ORDER BY s.created_at DESC LIMIT 8'
);

// Recent events (tournaments)
$upcomingEvents = Database::fetchAll(
    'SELECT * FROM events WHERE end_at >= NOW() ORDER BY start_at ASC LIMIT 5'
);

// Recent activity
$recentActivity = Database::fetchAll(
    "SELECT a.*, ad.username FROM audit_log a
     LEFT JOIN admins ad ON ad.id = a.admin_id
     ORDER BY a.created_at DESC LIMIT 10"
);

include __DIR__ . '/includes/header.php';
?>

<div class="page-header">
  <h1><?= I18n::t('dashboard.welcome') ?></h1>
  <div class="page-sub">v<?= APP_VERSION ?> — <?= date('Y-m-d H:i') ?></div>
</div>

<div class="grid-stats">
  <div class="stat-card stat-cyan">
    <div class="stat-label"><?= I18n::t('dashboard.players_online') ?></div>
    <div class="stat-val"><?= number_format($stats['players_online']) ?></div>
    <div class="stat-sub">إجمالي: <?= number_format($stats['total_players']) ?></div>
  </div>
  <div class="stat-card stat-green">
    <div class="stat-label"><?= I18n::t('dashboard.matches_today') ?></div>
    <div class="stat-val"><?= number_format($stats['matches_today']) ?></div>
  </div>
  <div class="stat-card stat-amber">
    <div class="stat-label"><?= I18n::t('dashboard.revenue_today') ?></div>
    <div class="stat-val">$<?= number_format($stats['revenue_today'], 2) ?></div>
    <div class="stat-sub">الشهر: $<?= number_format($stats['revenue_month'], 2) ?></div>
  </div>
  <div class="stat-card stat-violet">
    <div class="stat-label"><?= I18n::t('dashboard.active_rooms') ?></div>
    <div class="stat-val"><?= $stats['active_events'] ?></div>
    <div class="stat-sub">فعاليات نشطة</div>
  </div>
  <div class="stat-card">
    <div class="stat-label"><?= I18n::t('dashboard.retention_7d') ?></div>
    <div class="stat-val"><?= $stats['retention_7d'] ?>%</div>
  </div>
  <div class="stat-card stat-red">
    <div class="stat-label">بلاغات مفتوحة</div>
    <div class="stat-val"><?= $stats['open_reports'] ?></div>
    <a href="reports.php" class="stat-link">عرض ←</a>
  </div>
  <div class="stat-card">
    <div class="stat-label">خرائط/أطوار</div>
    <div class="stat-val"><?= $stats['total_scenarios'] ?></div>
  </div>
  <div class="stat-card">
    <div class="stat-label">حالة النظام</div>
    <div class="stat-val stat-status <?= FEATURE_MAINTENANCE_MODE ? 'down' : 'up' ?>">
      <?= FEATURE_MAINTENANCE_MODE ? 'صيانة' : 'متصل' ?>
    </div>
  </div>
</div>

<div class="grid-2col">
  <div class="panel">
    <div class="panel-header">
      <h3>أحدث المبيعات</h3>
      <a href="receipts.php" class="btn small">عرض الكل</a>
    </div>
    <table class="data-table">
      <thead><tr><th>اللاعب</th><th>SKU</th><th>المبلغ</th><th>الحالة</th><th>التاريخ</th></tr></thead>
      <tbody>
        <?php if (empty($recentSales)): ?>
          <tr><td colspan="5" class="text-center text-muted">لا توجد مبيعات بعد</td></tr>
        <?php else: foreach ($recentSales as $s): ?>
          <tr>
            <td><?= Security::escape($s['display_name'] ?? $s['player_id']) ?></td>
            <td><code><?= Security::escape($s['sku']) ?></code></td>
            <td>$<?= number_format($s['amount_usd'], 2) ?></td>
            <td><span class="badge badge-<?= $s['status'] === 'verified' ? 'ok' : 'pending' ?>"><?= Security::escape($s['status']) ?></span></td>
            <td class="text-muted"><?= Security::escape($s['created_at']) ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <div class="panel">
    <div class="panel-header">
      <h3>الفعاليات المجدولة</h3>
      <a href="events.php" class="btn small primary">+ <?= I18n::t('events.create') ?></a>
    </div>
    <table class="data-table">
      <thead><tr><th>الفعالية</th><th>النوع</th><th>من</th><th>إلى</th><th>الحالة</th></tr></thead>
      <tbody>
        <?php foreach ($upcomingEvents as $e): ?>
          <tr>
            <td>
              <strong><?= Security::escape($e['title_key']) ?></strong>
              <?php if ($e['is_featured']): ?><span class="badge featured">⭐</span><?php endif; ?>
            </td>
            <td><span class="badge"><?= Security::escape($e['event_type']) ?></span></td>
            <td class="text-muted"><?= Security::escape(substr($e['start_at'], 0, 16)) ?></td>
            <td class="text-muted"><?= Security::escape(substr($e['end_at'], 0, 16)) ?></td>
            <td>
              <?php if ($e['is_active'] && strtotime($e['start_at']) <= time() && strtotime($e['end_at']) >= time()): ?>
                <span class="badge badge-ok">نشطة</span>
              <?php elseif (strtotime($e['start_at']) > time()): ?>
                <span class="badge pending">قادمة</span>
              <?php else: ?>
                <span class="badge">منتهية</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="panel">
  <div class="panel-header">
    <h3>آخر نشاط إداري</h3>
    <a href="audit.php" class="btn small">عرض السجل الكامل</a>
  </div>
  <table class="data-table">
    <thead><tr><th>المدير</th><th>الإجراء</th><th>الكيان</th><th>التفاصيل</th><th>التاريخ</th></tr></thead>
    <tbody>
      <?php foreach ($recentActivity as $a): ?>
        <tr>
          <td><?= Security::escape($a['username'] ?? '—') ?></td>
          <td><code><?= Security::escape($a['action']) ?></code></td>
          <td><?= Security::escape(($a['entity_type'] ?? '') . ($a['entity_id'] ? ': ' . $a['entity_id'] : '')) ?></td>
          <td class="text-muted small"><?= Security::escape(substr($a['details'] ?? '', 0, 60)) ?></td>
          <td class="text-muted"><?= Security::escape($a['created_at']) ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>