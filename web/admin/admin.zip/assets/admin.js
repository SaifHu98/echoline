/* ============================================================
   ECHO//LINE — Admin Panel Client JS
   ============================================================ */
(function () {
  'use strict';

  // Create toast host
  const host = document.createElement('div');
  host.className = 'toast-host';
  document.body.appendChild(host);

  window.showToast = function (msg, type = 'info') {
    const el = document.createElement('div');
    el.className = 'toast-client ' + type;
    el.textContent = msg;
    host.appendChild(el);
    setTimeout(() => {
      el.classList.add('fade-out');
      setTimeout(() => el.remove(), 300);
    }, 2800);
  };

  // Confirm dialog helper
  window.confirmAction = function (msg) {
    return new Promise(resolve => resolve(confirm(msg)));
  };

  // Mobile sidebar toggle
  const sidebar = document.querySelector('.sidebar');
  if (sidebar && window.innerWidth <= 900) {
    const btn = document.createElement('button');
    btn.className = 'btn';
    btn.textContent = '☰';
    btn.style.cssText = 'position:fixed;top:1rem;left:1rem;z-index:999;';
    btn.onclick = () => sidebar.classList.toggle('open');
    document.body.appendChild(btn);
  }
})();